document.addEventListener("DOMContentLoaded", function () {
  const num1Input = document.getElementById("num1");
  const num2Input = document.getElementById("num2");
  const addButton = document.getElementById("addButton");
  const resultElement = document.getElementById("result");

  addButton.addEventListener("click", function () {
    const num1 = num1Input.value;
    const num2 = num2Input.value;

    if (!isNaN(num1) || !isNaN(num2)) {
      const sum = num1 + num2;
      resultElement.textContent = `Result: ${num1} + ${num2} = ${sum}`;
    } else {
      resultElement.textContent = "Please enter valid numbers.";
    }
  });
});
