document.addEventListener("DOMContentLoaded", () => {
  const quoteText = document.getElementById("quote-text");
  const quoteAuthor = document.getElementById("quote-author");
  const generateButton = document.getElementById("generate-button");

  generateButton.addEventListener("click", function () {
    try {
      const res = fetch("https://api.quotable.io/random");
      const data = res.json();

      const quote = data.content;
      const author = data.author;

      quoteText.textContent = `"${quote}"`;
      quoteAuthor.textContent = `- ${author}`;
    } catch (error) {
      alert(error);
    }
  });
});
