console.log("Welcome!");

let songindex = 0;
let audioelement = new Audio('perfect.mp3');
let masterPlay = document.getElementById('masterPlay');
let myprogressbar = document.getElementById('myprogressbar');
let songs = [
    {songname:"Perfect", filepath:"perfect.mp3", coverpath:"perfect.jpg"},
    {songname:"Perfect", filepath:"perfect.mp3", coverpath:"perfect.jpg"},
    {songname:"Perfect", filepath:"perfect.mp3", coverpath:"perfect.jpg"},
    {songname:"Perfect", filepath:"perfect.mp3", coverpath:"perfect.jpg"},
]

masterPlay.addEventListener('click', ()=>{
    if(audioelement.paused || audioelement.currentTime<=0){
        audioelement.play();
        masterPlay.classList.remove('fa-google-play');
        masterPlay.classList.add('fa-pause-circle');
    }
    else{
        audioelement.pause();
        masterPlay.classList.remove('fa-pause-circle');
        masterPlay.classList.add('fa-google-play');
    }
})

audioelement.addEventListener('timeupdate', ()=>{
    

    progress = parseInt((audioelement.currentTime/audioelement.duration)*100);

    myprogressbar.value = progress;
})

myprogressbar.addEventListener('change', ()=>{
    audioelement.currentTime = myprogressbar.value * audioelement.duration/100;
})